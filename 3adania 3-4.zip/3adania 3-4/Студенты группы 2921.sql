USE Polyanskaya_36
SELECT * FROM Students
        WHERE N_groop LIKE '2921'