USE Polyanskaya_36
SELECT * FROM Students
        WHERE Last_name LIKE '�%'