Use Polyanskaya_36
INSERT INTO Groops(N_groop, kod_spec)
VALUES (145, 2201);
 
INSERT INTO Groops(N_groop, kod_spec)
VALUES (2921, 1901)
INSERT INTO Groops(N_groop, kod_spec)
VALUES (4841, 554)